package railway;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class ContactPage extends GeneralPage {

    //Locators
    public final By emailLink = By.xpath("//div[@class='contact']//b[contains(text(),'Email')]//following-sibling::a");

    //Elements
    protected WebElement getEmailLink() {
        return getElement(emailLink);
    }

    //Methods
    protected String getAdminEmailHref(){
        return getEmailLink().getAttribute("href");
    }
}
