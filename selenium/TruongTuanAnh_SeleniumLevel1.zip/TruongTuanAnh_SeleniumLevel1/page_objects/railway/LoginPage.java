package railway;

import objects.Account;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class LoginPage extends GeneralPage {

    //Locators
    protected final By txtUsername = By.id("username");
    protected final By txtPassword = By.id("password");
    protected final By btnLogin = By.xpath("//input[@value='Login']");
    protected final By lblErrorMsg = By.xpath("//p[@class='message error LoginForm']");
    protected final By linkForgotPassword = By.xpath("//a[@href='/Account/ForgotPassword.cshtml']");

    //Elements
    protected WebElement getTxtUsername() {
        return getElement(txtUsername);
    }

    protected WebElement getTxtPassword() {
        return getElement(txtPassword);
    }

    protected WebElement getBtnLogin() {
        return getElement(btnLogin);
    }

    protected WebElement getErrorMsg() {
        return getElement(lblErrorMsg);
    }

    protected WebElement getLinkForgotPassword() {
        return getElement(linkForgotPassword);
    }

    //Methods
    public void gotoForgotPasswordPage() {
        getLinkForgotPassword().click();
    }

    public boolean doesErrorMessageExist(){
        return doesControlExist(lblErrorMsg);
    }

    public void login(Account account) {
        enterDataToTextbox(getTxtUsername(), account.getEmail());
        enterDataToTextbox(getTxtPassword(), account.getPassword());
        clickOnElement(getBtnLogin());
    }

    public void loginMutipleTimes(Account account,int times) {
        while (times>0)
        {
            login(account);
            times--;
        }
    }
}
