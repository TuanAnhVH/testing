package railway;

import common.CommonActions;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class GeneralPage extends CommonActions {

    //locators
    protected final By tabContact = By.xpath("//div[@id='menu']//a[@href='/Page/Contact.cshtml']");
    protected final By tabTicketPrice = By.xpath("//div[@id='menu']//a[@href='/Page/TrainPriceListPage.cshtml']");
    protected final By tabBookTicket = By.xpath("//div[@id='menu']//a[@href='/Page/BookTicketPage.cshtml']");
    protected final By tabMyTicket = By.xpath("//div[@id='menu']//a[@href='/Page/ManageTicket.cshtml']");
    protected final By tabRegister = By.xpath("//div[@id='menu']//a[@href='/Account/Register.cshtml']");
    protected final By tabChangePassword = By.xpath("//div[@id='menu']//a[@href='/Account/ChangePassword.cshtml']");
    protected final By tabLogin = By.xpath("//div[@id='menu']//a[@href='/Account/Login.cshtml']");
    protected final By tabLogout = By.xpath("//div[@id='menu']//a[@href='/Account/Logout']");
    protected final By lblWelcomeMessage = By.xpath("//div[@class='account']/strong");

    //Elements
    protected WebElement getTabContact() {
        return getElement(tabContact);
    }

    protected WebElement getTabTicketPrice() {
        return getElement(tabTicketPrice);
    }

    protected WebElement getTabBookTicket() {
        return getElement(tabBookTicket);
    }

    protected WebElement getTabMyTicket() {
        return getElement(tabMyTicket);
    }

    protected WebElement getRegister() {
        return CommonActions.getElement(tabRegister);
    }

    protected WebElement getTabChangePassword() { return getElement(tabChangePassword); }

    protected WebElement getTabLogin() {
        return getElement(tabLogin);
    }

    protected WebElement getLblWelcomeMessage() { return getElement(lblWelcomeMessage); }

    //Methods
    public void goToContactPage() {
        getTabContact().click();
    }

    public void goToTicketPricePage() { getTabTicketPrice().click(); }

    public void goToBookTicketPage() {
        getTabBookTicket().click();
    }

    public void goToMyTicketPage() {
        getTabMyTicket().click();
    }

    public void goToRegisterPage() { getRegister().click(); }

    public void goToChangePasswordPage() { getTabChangePassword().click(); }

    public void goToLoginPage() {
        getTabLogin().click();
    }

    public boolean doesMyTicketTabExist(){
        return doesControlExist(tabMyTicket);
    }

    public boolean doesChangePasswordTabExist(){ return doesControlExist(tabChangePassword); }

    public boolean doesLogoutTabExist(){
        return doesControlExist(tabLogout);
    }

    public boolean isUserLoggedIn(){ return  doesLogoutTabExist(); }

    public boolean isMyTicKetPageDisplaying(){
        String path = "//div[@id='menu']//li[@class='selected']//a[@href='/Page/ManageTicket.cshtml']";
        return doesControlExist(By.xpath(path));
    }

    public boolean isChangePasswordPageDisplaying(){
        String path = "//div[@id='menu']//li[@class='selected']//a[@href='/Account/ChangePassword.cshtml']";
        return doesControlExist(By.xpath(path));
    }
}
