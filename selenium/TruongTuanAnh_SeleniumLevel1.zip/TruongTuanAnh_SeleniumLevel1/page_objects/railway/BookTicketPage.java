package railway;


import constant.Constant;
import objects.Ticket;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class BookTicketPage extends GeneralPage {

    //Locators
    protected final By lblBookingError = By.xpath("//p[@class='message error']");
    protected final By lblTicketAmountError = By.xpath("//select[@name='TicketAmount']//following-sibling::label");
    protected final By cbbDepartDate = By.name("Date");
    protected final By cbbDepartStation = By.name("DepartStation");
    protected final By cbbArriveStation = By.name("ArriveStation");
    protected final By cbbSeatType = By.name("SeatType");
    protected final By cbbTicketAmount = By.name("TicketAmount");
    protected final By btnBookTicket = By.xpath("//input[@value='Book ticket']");

    //Elements
    protected Select getCbbDepartDate() {
        return new Select(getElement(cbbDepartDate));
    }

    protected Select getCbbDepartStation() {
        return new Select(getElement(cbbDepartStation));
    }

    protected Select getCbbArriveStation() {
        return new Select(getElement(cbbArriveStation));
    }

    protected Select getCbbSeatType() {
        return new Select(getElement(cbbSeatType));
    }

    protected Select getCbbTicketAmount() {
        return new Select(getElement(cbbTicketAmount));
    }

    protected WebElement getBtnBookTicket() {
        return getElement(btnBookTicket);
    }

    protected WebElement getLblBookingError() {
        return getElement(lblBookingError);
    }

    protected WebElement getLblTicketAmountError() {
        return getElement(lblTicketAmountError);
    }

    //methods
    public String getSelectedItem(String selectName) {
        String path = String.format("//select[@name='%s']//option[@selected='selected']", selectName);
        return this.getElement(By.xpath(path)).getText();
    }

    public String getSelectedDepartStation() {
        return getSelectedItem("DepartStation");
    }

    public String getSelectedArriveStation() {
        return getSelectedItem("ArriveStation");
    }

    public String getSelectedSeatType() {
        return getSelectedItem("SeatType");
    }

    public void bookTicket(Ticket ticket) {
        selectItem(getCbbDepartDate(), ticket.getDepartDate());
        selectItem(getCbbDepartStation(), ticket.getDepartStation());
        selectItem(getCbbSeatType(), ticket.getSeatType());
        selectItem(getCbbTicketAmount(), ticket.getAmount());
        waiForControlClickable(cbbArriveStation);
        selectItem(getCbbArriveStation(), ticket.getArriveStation());
        clickOnElement(getBtnBookTicket());
    }
}
