package railway;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class RegisterPage extends GeneralPage{

    //Locators
    protected final By txtEmail = By.id("email");
    protected final By txtPassword = By.id("password");
    protected final By txtConfirmPassword = By.id("confirmPassword");
    protected final By txtPID = By.id("pid");
    protected final By btnRegister = By.xpath("//input[@value='Register']");
    protected final By lblRegisterSuccessMsg = By.xpath("//div[@id='content']/p");
    protected final By lblRegisterErrorMsg = By.xpath("//p[@class='message error']");
    protected final By lblPasswordError = By.xpath("//label[@for='password' and @class='validation-error']");
    protected final By lblPIDError = By.xpath("//label[@for='pid' and @class='validation-error']");

    //Elements
    protected WebElement getTxtEmail() { return getElement(txtEmail); }

    protected WebElement getTxtPassword() {
        return getElement(txtPassword);
    }

    protected WebElement getTxtConfirmPassword() { return getElement(txtConfirmPassword); }

    protected WebElement getTxtPID() {
        return getElement(txtPID);
    }

    protected WebElement getBtnRegister() { return getElement(btnRegister); }

    protected WebElement getLblSuccessMsg() { return getElement(lblRegisterSuccessMsg);}

    protected WebElement getLblErrorMsg() { return getElement(lblRegisterErrorMsg); }

    protected WebElement getLblPasswordError() { return getElement(lblPasswordError); }

    protected WebElement getLblPIDError() { return getElement(lblPIDError); }

    //Methods
    public void register(String email, String password, String confirmPassword, String pidNumber) {
        enterDataToTextbox(getTxtEmail(), email);
        enterDataToTextbox(getTxtPassword(), password);
        enterDataToTextbox(getTxtConfirmPassword(), confirmPassword);
        enterDataToTextbox(getTxtPID(), pidNumber);
        clickOnElement(getBtnRegister());
    }
}
