package railway;

public class HomePage extends GeneralPage{

}
