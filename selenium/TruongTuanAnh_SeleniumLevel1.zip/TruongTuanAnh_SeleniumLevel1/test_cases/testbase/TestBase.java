package testbase;

import common.CommonActions;
import constant.Constant;
import org.testng.annotations.*;

public class TestBase extends CommonActions {

    @Parameters("browser")
    @BeforeClass()
    public void beforeClass(@Optional("Chrome") String browser) {
        System.out.println("Pre-condition");
        setUpBrowser(browser);
        maximizeBrowser();
        CommonActions.navigateToRailway();
    }

    @AfterClass
    public void afterClass() {
        System.out.println("Post-condition");
        Constant.WEBDRIVER.quit();
    }

    @DataProvider(name = "getDataObjects")
    public Object[] getDataObjects() {
        String className = getClass().getSimpleName();
        return getData(className, Constant.DATA_FILE_PATH);
    }
}
