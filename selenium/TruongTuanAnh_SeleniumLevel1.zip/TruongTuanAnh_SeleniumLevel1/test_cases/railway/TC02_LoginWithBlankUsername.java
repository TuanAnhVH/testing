package railway;

import constant.Constant;
import objects.Account;
import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC02_LoginWithBlankUsername extends TestBase {
    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();

    @Test(dataProvider = "getDataObjects")
    public void TC02(Hashtable<String, String> data) {
        System.out.println("TC02 - User can't login with blank 'User name' textbox");

        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login with blank user name.");
        Account account = new Account("", Constant.PASSWORD);
        loginPage.login(account);

        System.out.println("Check that the user is logged in?");
        Assert.assertFalse(homePage.isUserLoggedIn(),"The user has been logged in");

        System.out.println("Check the error message displays.");
        Assert.assertEquals(loginPage.getErrorMsg().getText(), data.get("expectedMessage"));
    }
}
