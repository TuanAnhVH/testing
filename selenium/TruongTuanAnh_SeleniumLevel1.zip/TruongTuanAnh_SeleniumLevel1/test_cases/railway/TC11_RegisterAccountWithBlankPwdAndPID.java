package railway;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testbase.TestBase;

import java.util.Hashtable;

public class TC11_RegisterAccountWithBlankPwdAndPID extends TestBase {
    HomePage homePage = new HomePage();
    RegisterPage registerPage = new RegisterPage();

    @Test(dataProvider = "getDataObjects")
    public void TC11(Hashtable<String, String> data) {
        System.out.println("TC11 - User can't create account while password and PID fields are empty");
        SoftAssert softAssert = new SoftAssert();

        System.out.println("Go to the 'Register' page.");
        homePage.goToRegisterPage();

        System.out.println("Register with password and PID are blank");
        registerPage.register(getRandomEmail(), "", "", "");

        System.out.println("Check the register message displays.");
        softAssert.assertEquals(registerPage.getLblErrorMsg().getText(), data.get("expectedRegisterMessage"));

        System.out.println("Check the error password message displays.");
        softAssert.assertEquals(registerPage.getLblPasswordError().getText(), data.get("expectedPasswordMessage"));

        System.out.println("Check the error PID message displays.");
        softAssert.assertEquals(registerPage.getLblPIDError().getText(), data.get("expectedPIDMessage"));

        System.out.println("Report the checking result.");
        softAssert.assertAll();
    }
}
