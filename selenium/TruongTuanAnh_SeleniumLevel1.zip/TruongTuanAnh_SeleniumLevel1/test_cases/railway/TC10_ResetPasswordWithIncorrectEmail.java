package railway;

import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC10_ResetPasswordWithIncorrectEmail extends TestBase {
    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();
    ForgotPasswordPage forgotPasswordPage = new ForgotPasswordPage();

    @Test(dataProvider = "getDataObjects")
    public void TC10(Hashtable<String, String> data) {
        System.out.println("TC10 - User can't reset password if enter incorrect email address");

        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Go to 'Forgot Password' page.");
        loginPage.gotoForgotPasswordPage();

        System.out.println("Reset password with invalid Email.");
        forgotPasswordPage.resetPassword(data.get("email"));

        System.out.println("Check the error message displays.");
        Assert.assertEquals(forgotPasswordPage.getErrorMsg().getText(), data.get("expectedMessage"));
    }
}
