package railway;

import constant.Constant;
import objects.Account;
import objects.Ticket;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testbase.TestBase;

import java.util.Hashtable;

public class TC15_GoToBookTicketPageFromTicketPricePage extends TestBase {
    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();
    BookTicketPage bookTicketPage = new BookTicketPage();
    TicketPricePage ticketPricePage = new TicketPricePage();
    TrainPriceListPage trainPriceListPage = new TrainPriceListPage();

    @Test(dataProvider = "getDataObjects")
    public void TC15(Hashtable<String, String> data) {
        System.out.println("TC15 - User can open 'Book ticket' page by click on 'Book ticket' link in 'Ticket price' page");
        Account account = new Account(Constant.EMAIL, Constant.PASSWORD);
        SoftAssert softAssert = new SoftAssert();
        Ticket ticket = new Ticket(data.get("departDate"), data.get("departStation"), data.get("arriveStation"), data.get("seatType"), data.get("amount"));

        System.out.println("Go to the 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login with a valid account.");
        loginPage.login(account);

        System.out.println("Go to 'Ticket price' page.");
        homePage.goToTicketPricePage();

        System.out.println("go to 'Check price a ticket' page.");
        trainPriceListPage.clickBtnCheckPrice(ticket.getDepartStation(), ticket.getArriveStation());

        System.out.println("Book a ticket.");
        ticketPricePage.clickBtnBookTicket(ticket.getSeatType());

        System.out.println("Check that displayed values are correct?");
        softAssert.assertEquals(bookTicketPage.getSelectedDepartStation(), ticket.getDepartStation());
        softAssert.assertEquals(bookTicketPage.getSelectedArriveStation(), ticket.getArriveStation());
        softAssert.assertEquals(bookTicketPage.getSelectedSeatType(), ticket.getSeatType());
        softAssert.assertAll();
    }
}
