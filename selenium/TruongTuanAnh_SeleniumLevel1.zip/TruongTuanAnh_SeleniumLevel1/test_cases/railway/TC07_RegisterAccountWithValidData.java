package railway;

import constant.Constant;
import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC07_RegisterAccountWithValidData extends TestBase {
    HomePage homePage = new HomePage();
    RegisterPage registerPage = new RegisterPage();

    @Test(dataProvider = "getDataObjects")
    public void TC07(Hashtable<String, String> data) {
        System.out.println("TC07 - User can create new account");

        System.out.println("Go to 'Register' page.");
        homePage.goToRegisterPage();

        System.out.println("Register a account with valid data.");
        registerPage.register(getRandomEmail(), Constant.PASSWORD, Constant.PASSWORD, Constant.PID);

        System.out.println("Check the register message displays.");
        Assert.assertEquals(registerPage.getLblSuccessMsg().getText(), data.get("expectedMessage"));
    }
}
