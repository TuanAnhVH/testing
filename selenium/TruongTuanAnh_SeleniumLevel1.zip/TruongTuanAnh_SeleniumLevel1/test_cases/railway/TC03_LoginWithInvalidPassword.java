package railway;

import objects.Account;
import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC03_LoginWithInvalidPassword extends TestBase {
    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();

    @Test(dataProvider = "getDataObjects")
    public void TC03(Hashtable<String, String> data) {
        System.out.println("TC03 - User cannot log into Railway with invalid password");

        System.out.println("Go to 'Login' page");
        homePage.goToLoginPage();

        System.out.println("Login with invalid password.");
        Account account = new Account(data.get("email"), data.get("password"));
        loginPage.login(account);

        System.out.println("Check that the user is logged in?");
        Assert.assertFalse(homePage.isUserLoggedIn(),"The user has been logged in");

        System.out.println("Check the error message displays");
        Assert.assertEquals(loginPage.getErrorMsg().getText(), data.get("expectedMessage"));
    }
}
