package railway;

import constant.Constant;
import objects.Account;
import objects.Ticket;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC16_CancelTicket extends TestBase {
    HomePage homePage = new HomePage();
    RegisterPage registerPage = new RegisterPage();
    LoginPage loginPage = new LoginPage();
    BookTicketPage bookTicketPage = new BookTicketPage();
    MyTicketPage myTicketPage = new MyTicketPage();
    Account account;

    @BeforeMethod
    public void beforeMethod() {
        String email = getRandomEmail();
        String password = Constant.PASSWORD;

        System.out.println("Go to 'Register' page.");
        homePage.goToRegisterPage();

        System.out.println("Create a new account");
        registerPage.register(email, password, password, Constant.PID);
        account = new Account(email, password);
    }

    @Test(dataProvider = "getDataObjects")
    public void TC16(Hashtable<String, String> data) {
        System.out.println("TC16 - User can cancel a ticket.");
        Ticket ticket = new Ticket(data.get("departDate"), data.get("departStation"), data.get("arriveStation"), data.get("seatType"), data.get("amount"));


        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login with a valid account.");
        loginPage.login(account);

        System.out.println("Go to 'Book ticket' page.");
        homePage.goToBookTicketPage();

        System.out.println("Book a ticket.");
        bookTicketPage.bookTicket(ticket);

        System.out.println("Go to 'My ticket' page");
        homePage.goToMyTicketPage();

        System.out.println("Cancel the recent booked ticket.");
        myTicketPage.cancelTicket(ticket.getDepartStation(), ticket.getArriveStation());

        System.out.println("confirm canceling.");
        Constant.WEBDRIVER.switchTo().alert().accept();

        System.out.println("Check that the recent canceled ticket is disappeared?");
        homePage.goToMyTicketPage();
        Assert.assertFalse(myTicketPage.doesTicketExist(ticket.getDepartStation(), ticket.getArriveStation()), "The ticket has not been canceled");
    }
}
