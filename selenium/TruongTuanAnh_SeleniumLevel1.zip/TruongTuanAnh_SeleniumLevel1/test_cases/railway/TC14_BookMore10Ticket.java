package railway;

import constant.Constant;
import objects.Account;
import objects.Ticket;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testbase.TestBase;

import java.util.Hashtable;

public class TC14_BookMore10Ticket extends TestBase {
    RegisterPage registerPage = new RegisterPage();
    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();
    BookTicketPage bookTicketPage = new BookTicketPage();
    Account account;

    @BeforeMethod
    public void beforeMethod() {
        String email = getRandomEmail();
        String password = Constant.PASSWORD;

        System.out.println("Go to 'Register' page.");
        homePage.goToRegisterPage();

        System.out.println("Create a new account");
        registerPage.register(email, password, password, Constant.PID);
        account = new Account(email, password);
    }

    @Test(dataProvider = "getDataObjects")
    public void TC14(Hashtable<String, String> data) {
        System.out.println("TC14 - User can't book more than 10 tickets");
        SoftAssert softAssert = new SoftAssert();
        Ticket ticket = new Ticket(data.get("departDate"), data.get("departStation"), data.get("arriveStation"), data.get("seatType"), data.get("amount"));

        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login with a valid account.");
        loginPage.login(account);

        System.out.println("Go to the 'Book ticket' page.");
        homePage.goToBookTicketPage();

        System.out.println("Book 10 tickets.");
        bookTicketPage.bookTicket(ticket);

        System.out.println("Book more tickets.");
        homePage.goToBookTicketPage();
        ticket.setAmount("1");
        bookTicketPage.bookTicket(ticket);

        System.out.println("Check the book ticket message displays.");
        softAssert.assertEquals(bookTicketPage.getLblBookingError().getText(), data.get("expectedBookingMessage"));

        System.out.println("Check the amount ticket message displays.");
        softAssert.assertEquals(bookTicketPage.getLblTicketAmountError().getText(), data.get("expectedTicketAmountMessage"));

        System.out.println("Report the checking result");
        softAssert.assertAll();
    }
}
