package railway;

import objects.Account;
import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC05_LoginSeveralTimeWithWrongPassword extends TestBase {

    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();

    @Test(dataProvider = "getDataObjects")
    public void TC05(Hashtable<String, String> data) {
        System.out.println("TC05 - System shows message when user enters wrong password several times");

        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login several times with invalid password.");
        Account account = new Account(data.get("email"), data.get("password"));
        loginPage.loginMutipleTimes(account, 4);

        System.out.println("Check the error message displays");
        Assert.assertEquals(loginPage.getErrorMsg().getText(), data.get("expectedMessage"));
    }
}
