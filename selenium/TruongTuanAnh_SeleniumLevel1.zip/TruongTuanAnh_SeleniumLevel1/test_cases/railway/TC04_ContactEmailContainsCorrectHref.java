package railway;

import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC04_ContactEmailContainsCorrectHref extends TestBase {
    HomePage homePage = new HomePage();
    ContactPage contactPage = new ContactPage();

    @Test(dataProvider = "getDataObjects")
    public void TC04(Hashtable<String, String> data) {
        System.out.println("TC04 - Contact Email contains correct href value which can help to quickly open Outlook Compose Message dialog");

        System.out.println("Go to 'Contact' page.");
        homePage.goToContactPage();

        System.out.println("Check the email address.");
        Assert.assertEquals(contactPage.getAdminEmailHref(), data.get("expectedHref"));
    }
}
