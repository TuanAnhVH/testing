package railway;

import constant.Constant;
import objects.Account;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import testbase.TestBase;

public class TC06_AdditionalPagesDisplayAfterLogin extends TestBase {

    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();
    GeneralPage generalPage = new GeneralPage();

    @Test
    public void TC06() {
        SoftAssert softAssert = new SoftAssert();
        System.out.println("TC06 - Additional pages display once user logged in");
        Account account = new Account(Constant.EMAIL, Constant.PASSWORD);

        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login to Railway.");
        loginPage.login(account);

        System.out.println("Check that additional pages are displayed?");
        softAssert.assertTrue(homePage.doesMyTicketTabExist(), "my ticket tab is not displayed");
        softAssert.assertTrue(homePage.doesChangePasswordTabExist(), "Change password tab is not displayed");
        softAssert.assertTrue(homePage.doesLogoutTabExist(), "Logout tab is not displayed");
        softAssert.assertAll();

        System.out.println("Go to 'My ticket' page.");
        generalPage.goToMyTicketPage();

        System.out.println("Check that the user has been directed to 'My ticket' page.");
        Assert.assertTrue(generalPage.isMyTicKetPageDisplaying(), "User has't been directed to 'My ticket' page");

        System.out.println("Go to 'Change password' page.");
        generalPage.goToChangePasswordPage();

        System.out.println("Check that the user has been directed to 'Change password' page");
        Assert.assertTrue(generalPage.isChangePasswordPageDisplaying(), "User has't been directed to 'Change password' page");
    }
}
