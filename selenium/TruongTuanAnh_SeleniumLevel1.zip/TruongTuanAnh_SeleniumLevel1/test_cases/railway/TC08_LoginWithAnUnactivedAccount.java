package railway;

import constant.Constant;
import objects.Account;
import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

import java.util.Hashtable;

public class TC08_LoginWithAnUnactivedAccount extends TestBase {
    HomePage homePage = new HomePage();
    RegisterPage registerPage = new RegisterPage();
    LoginPage loginPage = new LoginPage();

    @Test(dataProvider = "getDataObjects")
    public void TC08(Hashtable<String, String> data) {
        System.out.println("TC08 - User can't login with an account hasn't been activated");
        String email = getRandomEmail();
        String password = Constant.PASSWORD;

        System.out.println("Go to 'Register' page.");
        homePage.goToRegisterPage();

        System.out.println("Register a account with valid data.");
        registerPage.register(email, password, password, Constant.PID);
        Account account = new Account(email, password);

        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login with recent created account.");
        loginPage.login(account);

        System.out.println("Check that the user is logged in?");
        Assert.assertFalse(homePage.isUserLoggedIn(),"The user has been logged in");

        System.out.println("Check that the error message is displayed?");
        Assert.assertTrue(loginPage.doesErrorMessageExist(), "The error message is not displayed");

        System.out.println("Check the error message displays");
        Assert.assertEquals(loginPage.getErrorMsg().getText(), data.get("expectedMessage"));
    }
}
