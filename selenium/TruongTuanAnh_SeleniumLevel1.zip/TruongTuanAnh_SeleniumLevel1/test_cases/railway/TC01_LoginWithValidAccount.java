package railway;

import constant.Constant;
import objects.Account;
import org.testng.Assert;
import org.testng.annotations.Test;
import testbase.TestBase;

public class TC01_LoginWithValidAccount extends TestBase {
    HomePage homePage = new HomePage();
    LoginPage loginPage = new LoginPage();

    @Test()
    public void TC01() {
        System.out.println("TC01 - User can login to Railway with valid username and password");
        Account account = new Account(Constant.EMAIL, Constant.PASSWORD);
        System.out.println("Go to 'Login' page.");
        homePage.goToLoginPage();

        System.out.println("Login with a valid account.");
        loginPage.login(account);

        System.out.println("Check that the user is logged in?");
        Assert.assertTrue(homePage.isUserLoggedIn(),"The user has't been logged in");

        System.out.println("Check the welcome message displays.");
        String expectedMsg = "Welcome " + account.getEmail();
        Assert.assertEquals(homePage.getLblWelcomeMessage().getText(), expectedMsg);
    }
}
