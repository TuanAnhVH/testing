package constant;

import objects.Account;
import  org.openqa.selenium.WebDriver;

public class Constant {
    public static WebDriver WEBDRIVER;
    public static final String RAILWAY_URL = "http://railwayqa.somee.com";
    public static final String EMAIL = "satt200301@gmail.com";
    public static final String PASSWORD = "12345678";
    public static final String PID = "12345678";
    public static final String CHROME_DRIVER_LOCATE = ".\\Executables\\chromeDriver.exe";
    public static final String GECKO_DRIVER_LOCATE = ".\\Executables\\geckodriver.exe";
    public static final String DATA_FILE_PATH = ".\\resources\\json_files\\Data.json";
    public static final int TIME_WAIT_CONTROL_VISIBILITY = 5;
    public static final int TIME_WAIT_CONTROL_CLICKABLE = 10;
}
